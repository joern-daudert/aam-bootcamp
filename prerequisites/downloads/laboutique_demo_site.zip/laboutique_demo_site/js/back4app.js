function createUserPw() {
    $.ajax({
    url: "https://parseapi.back4app.com/users",
    dataType: "json",
    type: "post",
    headers: {
        "X-Parse-Application-Id":"pZ7gcIEOwVJfTTJNugzaqawpWHhNuD2HMXnAYAXO",
        "X-Parse-REST-API-Key":"pOjlc7a2tjN9FCbMTxhh38chZOnotUY6rDWJhmvo",
        "X-Parse-Revocable-Session":"1"
    },
    data: {
        "password": localStorage.getItem('password'),
        "username": localStorage.getItem('email'),
        "email": localStorage.getItem('email')
        }
    })
};